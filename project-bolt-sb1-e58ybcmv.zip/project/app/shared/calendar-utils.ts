import * as moment from 'moment';
import * as momentJalaali from 'moment-jalaali';
import { HijriDate } from 'hijri-dates';

export class CalendarUtils {
  static getGregorianDate(): string {
    return moment().format('YYYY-MM-DD');
  }

  static getPersianDate(): string {
    return momentJalaali().format('jYYYY/jMM/jDD');
  }

  static getHijriDate(): string {
    const hijri = new HijriDate();
    return `${hijri.getFullYear()}-${hijri.getMonth() + 1}-${hijri.getDate()}`;
  }

  static getMonthName(lang: 'en' | 'fa'): string {
    if (lang === 'fa') {
      return momentJalaali().format('jMMMM');
    }
    return moment().format('MMMM');
  }
}