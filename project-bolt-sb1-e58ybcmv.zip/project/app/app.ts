import { Application } from '@nativescript/core';
import './app.css';

Application.run({ moduleName: 'app-root' });