import { Observable } from '@nativescript/core';
import { CalendarUtils } from './shared/calendar-utils';
import { Utils } from '@nativescript/core';

export class MainViewModel extends Observable {
    private _language: string = 'fa';
    private _currentDate: string;
    private _hijriDate: string;
    private _gregorianDate: string;
    private _currentMonth: string;

    constructor() {
        super();
        this.updateDates();
    }

    get language(): string {
        return this._language;
    }

    toggleLanguage() {
        this._language = this._language === 'fa' ? 'en' : 'fa';
        this.updateDates();
        this.notifyPropertyChange('language', this._language);
    }

    updateDates() {
        this._currentDate = CalendarUtils.getPersianDate();
        this._hijriDate = CalendarUtils.getHijriDate();
        this._gregorianDate = CalendarUtils.getGregorianDate();
        this._currentMonth = CalendarUtils.getMonthName(this._language as 'en' | 'fa');
        
        this.notifyPropertyChange('currentDate', this._currentDate);
        this.notifyPropertyChange('hijriDate', this._hijriDate);
        this.notifyPropertyChange('gregorianDate', this._gregorianDate);
        this.notifyPropertyChange('currentMonth', this._currentMonth);
    }

    previousMonth() {
        // Implement previous month logic
        this.updateDates();
    }

    nextMonth() {
        // Implement next month logic
        this.updateDates();
    }

    openInstagram() {
        Utils.openUrl('https://www.instagram.com/hessamedien');
    }

    get currentDate(): string {
        return this._currentDate;
    }

    get hijriDate(): string {
        return this._hijriDate;
    }

    get gregorianDate(): string {
        return this._gregorianDate;
    }

    get currentMonth(): string {
        return this._currentMonth;
    }
}