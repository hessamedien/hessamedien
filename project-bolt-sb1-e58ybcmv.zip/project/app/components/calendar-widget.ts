import { Observable } from '@nativescript/core';
import { CalendarUtils } from '../shared/calendar-utils';

export class CalendarWidgetModel extends Observable {
    private _persianDate: string;
    private _hijriDate: string;
    private _gregorianDate: string;

    constructor() {
        super();
        this.updateDates();
    }

    private updateDates() {
        this._persianDate = CalendarUtils.getPersianDate();
        this._hijriDate = CalendarUtils.getHijriDate();
        this._gregorianDate = CalendarUtils.getGregorianDate();
        
        this.notifyPropertyChange('persianDate', this._persianDate);
        this.notifyPropertyChange('hijriDate', this._hijriDate);
        this.notifyPropertyChange('gregorianDate', this._gregorianDate);
    }

    get persianDate(): string {
        return this._persianDate;
    }

    get hijriDate(): string {
        return this._hijriDate;
    }

    get gregorianDate(): string {
        return this._gregorianDate;
    }
}